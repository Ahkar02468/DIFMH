

 
    

    // Navbar animation on scroll
    $(window).scroll(function() {
        if ($(document).scrollTop() > 10) {
          $('.navbar').addClass('scrolling-header');
        } else {
          $('.navbar').removeClass('scrolling-header');
        }
      });

   

   




